package com.dicoding.azureapp

data class Hero(
    var name: String = "",
    var desc: String = "",
    var photo: String = ""
)